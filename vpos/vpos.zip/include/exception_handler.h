#ifndef _VPOS_EXCEPTION_HANDLER_H_
#define  _VPOS_EXCEPTION_HANDLER_H_

void vk_undef_handler(void);
void vk_pabort_handler(void);
void vk_dabort_handler(void);
void vk_fiq_handler(void);
void vk_not_used_handler(void);

#endif //_VPOS_EXCEPTION_HANDLER_H_

